<script type="text/javascript">
    jQuery ( function($) {

        ZeroClipboard.setDefaults( { moviePath: '<?php echo WPCLONE_URL_PLUGIN ?>lib/js/ZeroClipboard.swf' } );

        /**workaround for firefox versions 18 and 19.
           https://bugzilla.mozilla.org/show_bug.cgi?id=829557
           https://github.com/jonrohan/ZeroClipboard/issues/73
        */
        var enableZC = true;
        var is_firefox18 = navigator.userAgent.toLowerCase().indexOf('firefox/18') > -1;
        var is_firefox19 = navigator.userAgent.toLowerCase().indexOf('firefox/19') > -1;
        if (is_firefox18 || is_firefox19) enableZC = false;

        if ( $( ".restore-backup-options" ).length ) {
            $( ".restore-backup-options" ).each( function() {
                var clip = new ZeroClipboard( $( "a.copy-button",this ) );
                /** FF 18/19 users won't see an alert box. */
                if (enableZC) {
                    clip.on( 'complete', function (client, args) {
                        alert( "Copied to clipboard:\n" + args.text );
                    });
                }
            });
        } else {
            var clip = new ZeroClipboard( $( "a.copy-button" ) );
            /** FF 18/19 users won't see an alert box. */
            if (enableZC) {
                clip.on( 'complete', function (client, args) {
                    alert( "Copied to clipboard:\n" + args.text );
                });
            }
        }
    });

</script>

<?php
if (wpa_wpfs_init()) return;

if( false === get_option( 'wpclone_backups' ) ) wpa_wpc_import_db();
$backups = get_option( 'wpclone_backups' );
?>
<div id="search-n-replace">
    <a href="#" id="close-thickbox" class="button">X</a>
    <form name="searchnreplace" action="#" method="post">
        <table class="searchnreplace">
            <tr><th><label for="searchfor">Search for</label></th><td colspan="5"><input type="text" name="searchfor" /></td></tr>
            <tr><th><label for="replacewith">Replace with</label></th><td colspan="5"><input type="text" name="replacewith" /></td></tr>
            <tr><th><label for="ignoreprefix">Ignore table prefix</label></th><td colspan="2"><input type="checkbox" name="ignoreprefix" value="true" /></td></tr>
        </table>
        <input type="submit" class="button" name="search-n-replace-submit" value="Run">
    </form>
    <div id="search-n-replace-info"></div>
</div>
<div id="wrapper">
<div id="MainView">

    <h1>Artistry Unfold</h1>
    <p>Launch sophisticated websites fast</p>
    <p>Select <strong>Install Artistry</strong> to upgrade any Wordpress website with thousands of dollars worth of the latest, premium plugins, themes and content with a click. </p>
    <p> Build your website. <strong>Make a clone</strong>. Then copy and paste the address of the clone into any Wordpress website that has the Artistry Unfold plugin installed. It is that simple.</p>
    <p>&nbsp;</p>

    <form id="backupForm" name="backupForm" action="#" method="post">
<?php
    if ( isset($_GET['mode']) && 'advanced' == $_GET['mode'] ) { ?>
        <div class="info width-60">
            <table>
                <tr align="left"><th colspan=""><label for="zipmode">Alternate zip method</label></th><td colspan="2"><input type="checkbox" name="zipmode" value="alt" /></td></tr>
                <tr align="left"><th><label for="use_wpdb">Use wpdb to backup the database</label></th><td colspan="2"><input type="checkbox" name="use_wpdb" value="true" /></td></tr>
                <tr align="left"><th><label for="ignore_prefix">Ignore table prefix</label></th><td colspan="2"><input type="checkbox" name="ignore_prefix" value="true" /></td></tr>
                <tr>
                    <td colspan="4">
                        <p>If enabled during a backup, all the tables in the database will be included in the backup.</br>
                        If enabled during a restore, search and replace will alter all the tables in the database.</br>
                        By default, only the tables that share the Artistry table prefix are included/altered during a backup/restore.</p>
                    </td>
                </tr>
                <tr align="left"><th><label for="mysql_check">Refresh MySQL connection during Restore</label></th><td colspan="2"><input type="checkbox" name="mysql_check" value="true" /></td></tr>
                <tr>
                    <td colspan="4">
                        <p>This will check the MySQL connection inside the main loop before each database query during restore. Enable this if the restored site is incomplete.</p>
                    </td>
                </tr>
                <tr><td colspan="4"><h3>Overriding the Maximum memory and Execution time</h3></td></tr>
                <tr><td colspan="4"><p>You can use these two fields to override the maximum memory and execution time on most hosts.</br>
                            For example, if you want to increase the RAM to 2GB, enter <code>2048</code> into the Maximum memory limit field.</br>
                            And if you want to increase the execution time to 15 minutes, enter <code>900</code> into the Script execution time field.</br>
                            Default values will be used if you leave them blank. The default value for RAM is 1024MB and the default value for execution time is 600 seconds (ten minutes).</p></td></tr>
                <tr align="left"><th><label for="maxmem">Maximum memory limit</label></th><td colspan="2"><input type="text" name="maxmem" /></td></tr>
                <tr align="left"><th><label for="maxexec">Script execution time</label></th><td><input type="text" name="maxexec" /></td></tr>
                <tr><td colspan="4"><h3>Exclude directories from backup, and backup database only</h3></td></tr>
                <tr><td colspan="4"><p>Depending on your web host, Artistry Unflod may  not work for large sites.
                            You may, however, exclude all of your 'wp-content' directory from the backup (use "Backup database only" option below), or exclude specific directories.
                            You would then copy these files over to the new site via FTP before restoring the backup with Artistry Unflod.</p>
                        <p>You could also skip files that are larger than the value entered into the below field. For example, enter <code>100</code> if you want to skip files larger than 100MB.
                            The default value of 25MB will be used If you leave it blank. Enter <code>0</code> if you want to disable it.</p></td></tr>
                <tr align="left"><th><label for="dbonly">Backup database only</label></th><td colspan="2"><input type="checkbox" name="dbonly" value="true" /></td></tr>
                <tr align="left"><th><label for="skipfiles">Skip files larger than</label></th><td><input type="text" name="skipfiles" />&nbsp;<strong>MB</strong></td></tr>
                <tr align="left"><th><label for="exclude">Excluded directories</label></th><td><textarea cols="70" rows="5" name="exclude" ></textarea></td></tr>
                <tr><th></th><td colspan="5"><p>Enter one per line, i.e.  <code>uploads/backups</code>,use the forward slash <code>/</code> as the directory separator. Directories start at 'wp-content' level.</br>
                </br>For example, BackWPup saves its backups into <code>/wp-content/uploads/backwpup-abc123-backups/</code> (the middle part, 'abc123' in this case, is random characters).
                If you wanted to exclude that directory, you have to enter <code>uploads/backwpup-abc123-backups</code> into the above field.</p></td></tr>
            </table>
        </div>
<?php
}
?>
        <span class="unfold-options">Make a clone</span>
        <input id="createBackup" name="createBackup" type="radio" value="fullBackup"/><br/><br/>

        <?php if( false !== $backups && ! empty( $backups ) ) : ?>

        <div class="try">

            <table class="restore-backup-options">

            <?php

                foreach ($backups AS $key => $backup) :

                $filename = convertPathIntoUrl(WPCLONE_DIR_BACKUP . $backup['name']);
                $url = wp_nonce_url( get_bloginfo('wpurl') . '/wp-admin/admin.php?page=wp-clone&del=' . $key, 'wpclone-submit');

            ?>
                <tr>
                    <th>Deploy a clone</th>

                    <td><input class="restoreBackup" name="restoreBackup" type="radio" value="<?php echo $filename ?>"/></td>

                    <td>
                        <a href="<?php echo $filename ?>" class="zclip"> (<?php echo bytesToSize($backup['size']);?>)&nbsp;&nbsp;<?php echo $backup['name'] ?></a>
                        <input type="hidden" name="backup_name" value="<?php echo $filename ?>" />
                    </td>
                    <?php
                        if( isset( $backup['log'] ) ){
                            printf( '<td><a href="%s">log</a></td>', convertPathIntoUrl(WPCLONE_DIR_BACKUP . $backup['log'] ) );
                        } else {
                            echo '<td>&mdash;</td>';
                        }
                    ?>
                    <td><a class="copy-button" href="#" data-clipboard-text="<?php echo $filename ?>" >Copy URL</a></td>
                    <td><a href="<?php echo $url; ?>" class="delete" data-fileid="<?php echo $key; ?>">Delete</a></td>

                </tr>

                <?php endforeach ?>

            </table>
        </div>

        <?php endif ?>
<br><br>
        <span class="unfold-options">Install Artistry </span><input id="backupUrl" name="backupUrl" type="radio" value="backupUrl"/>
        <p> If you have made a clone of an Artistry website already paste its location here. Otherwise leave the URL unchanged to install the latest version of Artistry. </p><br>

        <input type="text" name="restore_from_url" class="Url" value="https://artistry.ink/download/artistry-unfold.zip" size="80px"/><br/><br/>

        <div class="RestoreOptions" id="RestoreOptions">

            <input type="checkbox" name="approve" id="approve" /> I AGREE to perform an irreversable upgrade of this Wordpress site to Artistry:<br/>

            1. You have nothing of value in your current site <strong>[<?php echo site_url() ?>]</strong><br/>

            2. Your current site at <strong>[<?php echo site_url() ?>]</strong> may become unusable in case of failure,
            and you will need to re-install Wordpress<br/>

            3. Your Wordpress database <strong>[<?php echo DB_NAME; ?>]</strong> will be overwritten from the database in the backup file. <br/>

        </div>

        <input id="submit" name="submit" class="btn-primary btn" type="submit" value="Clone Now"/>


    <?php wp_nonce_field('wpclone-submit')?>
    </form>
    <?php
        if(!isset($_GET['mode'])){
            $link = admin_url( 'admin.php?page=wp-clone&mode=advanced' );
            echo "<p style='padding:5px;'><a href='{$link}' style='margin-top:10px'>Advanced Settings</a></p>";
        }


        echo "<p><a href='#' id='dirscan' class='button' style='margin-top:10px'>Scan and repopulate the backup list</a>"
        . "</br>Use the above button to refresh your backup list. It will list <em>all</em> the zip files found in the backup directory, it will also remove references to files that no longer exist.</p>";

        wpa_wpc_sysinfo();

        echo "<p><a href='#' id='uninstall' class='button' style='margin-top:10px'>Delete backups and remove database entries</a>"
        . "</br>Artistry Unflod does not remove backups when you deactivate the plugin. Use the above button if you want to remove all the backups.</p>";

        echo '<p><a href="#TB_inline?height=200&width=600&inlineId=search-n-replace&modal=true" class="thickbox">Search and Replace</a></p>';


    ?>
</div>
<div id="sidebar">
		<ul>
      <img src="//artistry.ink/wp-content/uploads/artistry-icon-black-white.png" width="250px">
			<h3>Help & Support</h3>
			<li><a href="https://artistry.ink/" target="_blank" title="Artistry">Artistry</a></li>
      <li><a href="https://artistry.ink/help" target="_blank" title="Artistry">Artistry Help</a></li>
      <li><a href="https://artistry.ink/downloads/plugins/artistry-unfold.zip" target="_blank" title="Artistry Unfold">Download Artistry Unfold Wordpress Plugin</a></li>

    </ul>

	</div>
</div> <!--wrapper-->
<p style="clear: both;" ></p>
<?php

    function wpa_wpc_sysinfo(){
        global $wpdb;
        echo '<div class="info width-60">';
        echo '<h3>System Info:</h3><p>';
        echo 'Memory limit: ' . ini_get('memory_limit');
        if( false === ini_set( 'memory_limit', '257M' ) ) {
            echo '&nbsp;<span style="color:#660000">memory limit cannot be increased</span></br>';
        } else {
            echo '</br>';
        }
        echo 'Maximum execution time: ' . ini_get('max_execution_time') . ' seconds</br>';
        echo 'PHP version : ' . phpversion() . '</br>';
        echo 'MySQL version : ' . $wpdb->db_version() . '</br>';
        if (ini_get('safe_mode')) { echo '<span style="color:#f11">PHP is running in safemode!</span></br>'; }
        printf( 'Root directory : <code>%s</code></br>', WPCLONE_ROOT );
        if ( ! file_exists( WPCLONE_DIR_BACKUP ) ) {
            echo 'Backup path :<span style="color:#660000">Backup directory not found. '
            . 'Unless there is a permissions or ownership issue, refreshing the backup list should create the directory.</span></br>';
        } else {
            echo 'Backup directory : <code>' . WPCLONE_DIR_BACKUP . '</code></br>';
        }
        echo 'Files : <span id="filesize"><img src="' . esc_url( admin_url( 'images/spinner.gif' ) ) . '"></span></br>';
        if ( file_exists( WPCLONE_DIR_BACKUP ) && !is_writable(WPCLONE_DIR_BACKUP)) { echo '<span style="color:#f11">Backup directory is not writable, please change its permissions.</span></br>'; }
        if (!is_writable(WPCLONE_WP_CONTENT)) { echo '<span style="color:#f11">wp-content is not writable, please change its permissions before you perform a restore.</span></br>'; }
        if (!is_writable(wpa_wpconfig_path())) { echo '<span style="color:#f11">wp-config.php is not writable, please change its permissions before you perform a restore.</span></br>'; }
        echo '</p></div>';
    }

/** it all ends here folks. */
